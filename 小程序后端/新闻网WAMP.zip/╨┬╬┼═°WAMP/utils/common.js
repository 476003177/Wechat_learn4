//获取新闻列表接口
var getNewList = 'http://127.0.0.1/myNews/Index/getNewsList'
//根据新闻ID获取新闻内容接口
var getNewById = 'http://127.0.0.1/myNews/Index/getNewsById'

//跳转新闻浏览页面
function goToDetail(id)
{
  wx.navigateTo({
    url: '../detail/detail?id=' + id,
  })
}

module.exports = {
  getNewList:getNewList,
  getNewById: getNewById,
  goToDetail:goToDetail
}